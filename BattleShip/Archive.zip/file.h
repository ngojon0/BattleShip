//
// Created by Kencha  Vang on 5/3/22.
//

#ifndef BATTLESHIP_FILE_H
#define BATTLESHIP_FILE_H

void get_file(std:: string file_name);

#endif //BATTLESHIP_FILE_H
