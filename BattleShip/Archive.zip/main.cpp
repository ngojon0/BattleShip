#include <iostream>
#include "file.h"

int main(int argc, char *argv[]) {
    char* file_name = argv[1];
    get_file(file_name);
}
